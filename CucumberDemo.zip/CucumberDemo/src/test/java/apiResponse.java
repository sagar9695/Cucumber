package stepdefinations

import io.restassured.RestAssured;

public class apiResponse {
	
	private static final string base_url="https://api.ratesapi.io/api/2010-01-12";
	@Given("Rates API for latest Foreign Exchange rates")
	public void rates_api_for_latest_foreign_exchange_rates() {
	 RestAssured.baseURI=base_url;
	 RequestSpecification request = RestAssured.given();
	 response = request.get("https://api.ratesapi.io/api/2010-01-12");
	 
	 jsonString = response.asString();
	 String code=JsonPath.from(jsonString).get("200");
	 Assert.assertTrue(200);
	}

	@When("The API is available")
	public void the_api_is_available() {
	    
	}

	@Then("An automated test suite should run which will assert the success status of the response")
	public void an_automated_test_suite_should_run_which_will_assert_the_success_status_of_the_response() {
		Assert.assertEquals(201, response.getStatusCode()); 
	}

}
